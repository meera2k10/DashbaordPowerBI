# Analytics Dashboard Demo

A responsive analytics dashboard built with React, featuring:
- Interactive charts and metrics
- Navigation system
- Responsive design
- Modern UI components

## Tech Stack
- React
- Recharts for data visualization
- Tailwind CSS for styling
- Lucide Icons
- shadcn/ui components

## Project Structure
```
src/
  components/
    Dashboard.jsx    # Main dashboard component
    Navigation.jsx   # Navigation sidebar
    HomePage.jsx     # Home page component
  App.jsx           # Root component
  index.js          # Entry point
```

## Setup Instructions
1. Clone the repository
2. Install dependencies:
```bash
npm install
# Required dependencies
npm install recharts lucide-react @radix-ui/react-slot
```

3. Start the development server:
```bash
npm run dev
```

## Features
- Interactive charts (Bar, Line, Pie)
- Real-time metrics display
- Responsive layout
- Dark mode navigation
- Clean, modern UI

## Component Usage
```jsx
import App from './App';

// Use in your React application
<App />
```