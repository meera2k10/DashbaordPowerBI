import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Settings, TrendingUp, Users, DollarSign, Home, BarChart2 } from 'lucide-react';

// Navigation Component
const Navigation = ({ activePage, setActivePage }) => {
  return (
    <div className="bg-gray-800 text-white w-64 min-h-screen p-4">
      <div className="text-xl font-bold mb-8">Analytics Portal</div>
      <nav>
        <button 
          onClick={() => setActivePage('home')}
          className={`w-full text-left p-3 rounded mb-2 flex items-center ${activePage === 'home' ? 'bg-gray-700' : 'hover:bg-gray-700'}`}
        >
          <Home className="mr-2 h-5 w-5" />
          Home
        </button>
        <button 
          onClick={() => setActivePage('dashboard')}
          className={`w-full text-left p-3 rounded mb-2 flex items-center ${activePage === 'dashboard' ? 'bg-gray-700' : 'hover:bg-gray-700'}`}
        >
          <BarChart2 className="mr-2 h-5 w-5" />
          Dashboard
        </button>
      </nav>
    </div>
  );
};

// Home Page Component
const HomePage = () => {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Welcome to Analytics Portal</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="text-xl font-bold mb-4">Getting Started</h2>
          <p className="text-gray-600">
            Access your analytics dashboard to view real-time metrics and insights about your business performance.
          </p>
        </Card>
        <Card className="p-6">
          <h2 className="text-xl font-bold mb-4">Quick Stats</h2>
          <div className="space-y-4">
            <div className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-blue-500" />
              <span>Active Users: 2,345</span>
            </div>
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-green-500" />
              <span>Growth Rate: 24.5%</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

// Dashboard Component
const Dashboard = () => {
  const salesData = [
    { month: 'Jan', sales: 4000, profit: 2400 },
    { month: 'Feb', sales: 3000, profit: 1398 },
    { month: 'Mar', sales: 2000, profit: 9800 },
    { month: 'Apr', sales: 2780, profit: 3908 },
    { month: 'May', sales: 1890, profit: 4800 },
    { month: 'Jun', sales: 2390, profit: 3800 },
  ];

  const metrics = [
    { title: 'Total Revenue', value: '$54,234', icon: DollarSign, change: '+14.2%' },
    { title: 'Active Users', value: '2,345', icon: Users, change: '+7.8%' },
    { title: 'Growth Rate', value: '24.5%', icon: TrendingUp, change: '+2.3%' },
    { title: 'Engagement', value: '78%', icon: Settings, change: '+9.1%' },
  ];

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Analytics Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {metrics.map((metric, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                  <h3 className="text-2xl font-bold mt-2">{metric.value}</h3>
                  <span className="text-sm text-green-600">{metric.change}</span>
                </div>
                <metric.icon className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mb-8">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-bold mb-4">Sales Performance</h2>
            <div className="h-96">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={salesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="sales" fill="#4F46E5" />
                  <Bar dataKey="profit" fill="#10B981" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Main App Component
const App = () => {
  const [activePage, setActivePage] = useState('home');

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Navigation activePage={activePage} setActivePage={setActivePage} />
      <main className="flex-1">
        {activePage === 'home' ? <HomePage /> : <Dashboard />}
      </main>
    </div>
  );
};

export default App;